package stepDefinations;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import com.pojo.AddAPI;
import com.pojo.Location;

import API.APIEND.PayLoad;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import static  io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertEquals;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class stepDefination {

	RequestSpecification res;
	ResponseSpecification resspec;
	Response response;

@Given("Add Place Payload")
public void add_place_payload() throws IOException {
    
	
	
	
	
	
		/*
		 * RestAssured.baseURI="https://rahulshettyacademy.com";
		 * 
		 * 
		 * String res= given().log().all().queryParam("key",
		 * "qaclick123").header("Content-Type","application/json") //.body(new
		 * String(Files.readAllBytes(Paths.
		 * get("D:\\H DRIVE\\New Volume\\API 2022\\file.json"))))
		 * 
		 * .body(PayLoad.addapi()) .when() .post("maps/api/place/add/json")
		 * .then().assertThat().log().all().statusCode(200).extract().response().
		 * asString();
		 * 
		 * 
		 * JsonPath js= new JsonPath(res);
		 * 
		 * String Place_ID= js.get("place_id");
		 * 
		 * System.out.println(Place_ID);
		 * 
		 * 
		 * 
		 * String address="Sydeny1234 Ratu 834001";
		 * 
		 * //Update place
		 * 
		 * given().log().all().queryParam("key",
		 * "qaclick123").header("Content-Type","application/json") .body("{\r\n" +
		 * "\"place_id\":\""+Place_ID+"\",\r\n" + "\"address\":\""+address+"\",\r\n" +
		 * "\"key\":\"qaclick123\"\r\n" + "\r\n" + "}") .when()
		 * .put("maps/api/place/update/json")
		 * .then().assertThat().log().all().statusCode(200).body("msg",
		 * equalTo("Address successfully updated")).extract().response().asString();
		 * 
		 * 
		 * // to get the api
		 * 
		 * 
		 * String response= given().log().all().queryParam("key",
		 * "qaclick123").header("Content-Type","application/json").queryParam(
		 * "place_id", Place_ID) .when().get("maps/api/place/get/json")
		 * .then().assertThat().log().all().statusCode(200).extract().response().
		 * asString();
		 * 
		 * 
		 * JsonPath js2= new JsonPath(response);
		 * 
		 * String expectedaddress= js2.get("address");
		 * 
		 * System.out.println(expectedaddress);
		 * 
		 */	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
RestAssured.baseURI="https://rahulshettyacademy.com";

		
		  AddAPI p= new AddAPI(); p.setAccuracy(50);
		  p.setAddress("29, side layout , cohen 09"); p.setLanguage("French-F");
		  p.setPhone_number("8754450659"); p.setWebsite("http://google.com");
		  p.setName("Dileep kumar"); List<String> myList=new ArrayList<String>();
		  
		  myList.add("shoe park"); myList.add("shop"); p.setTypes(myList);
		  
		  Location l= new Location(); l.setLat(-38.383494); l.setLng(33.427362);
		 
RequestSpecification req= new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com")
.setContentType(ContentType.JSON).build();

 resspec=new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();

 res=given().spec(req).body(p);




}


@When("user calls {string} with Post http request")
public void user_calls_with_post_http_request(String string) {
   
 response=res.when().post().then().spec(resspec).extract().response();
	
	
}


@Then("the API call is success with status code {int}")
public void the_api_call_is_success_with_status_code(Integer int1) {
	
	assertEquals(response.getStatusCode(),200);
	
	
	
}


@Then("{string} in response body is {string}")
public void in_response_body_is_ok(String addKey,String expectedvalue) {

String resp=	response.asString();

JsonPath js= new JsonPath(resp);

        js.get(addKey);
         
         assertEquals(js.get(addKey).toString(),expectedvalue);
	
}



@Then("{string} in resones body is {string}")
public void in_resones_body_is(String addscope, String expectedscope) {
	
	
	String resp=	response.asString();

JsonPath js1= new JsonPath(resp);

	    js1.get(addscope);
	         
	        assertEquals(js1.get(addscope),expectedscope);

	
}



	
	
	
	
	
	
	
}
