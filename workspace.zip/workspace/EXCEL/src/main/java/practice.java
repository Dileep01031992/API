import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class practice {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		ArrayList<String> list=new ArrayList<String>();
		
		File fs= new File("D:\\H DRIVE\\New Volume\\Selenium2022\\TestData\\Datadriven.xlsx");
		
		FileInputStream fis= new FileInputStream(fs);
		
		XSSFWorkbook book= new XSSFWorkbook(fis);
		
		 int sheetnum=       book.getNumberOfSheets();
		 
		 for(int i=0;i<sheetnum;i++) {
			 
			XSSFSheet sheet= book.getSheetAt(i);
			
			
			
			if(book.getSheetName(i).equals("TestData")) {
				
				  
			Iterator<Row> row=	sheet.rowIterator();
			
			Row firstrow=  row.next();
			
			 Iterator<Cell> ce=    firstrow.cellIterator();
			 
				
				  int k=0; int column=0; 
				  while(ce.hasNext()) {
				  
				  Cell value= ce.next();
				  
				  value.getStringCellValue();
				  
				  System.out.print(" "+value.getStringCellValue());
				  
				  if(value.getStringCellValue().equalsIgnoreCase("Name")) {
				  
				  column=k;
				  
				  }
				  
				  k++; }
				  
				  
	
			 
			System.out.print(column); 
			
			
			while(row.hasNext()) {
				
				
				 Row ros=  row.next();
				 
				 if(ros.getCell(column).getStringCellValue().equalsIgnoreCase("Prashant")) {
					 
					 
					Iterator<Cell> cls= ros.cellIterator();
					
					while(cls.hasNext()) {
						
						
						Cell cdr=cls.next();
						
						if(cdr.getCellType()==CellType.STRING) {
							
							
							list.add(cdr.getStringCellValue());
							
						}
						
						
						else {
							
							
							cdr.getNumericCellValue();
							
							NumberToTextConverter.toText(cdr.getNumericCellValue());
							
							list.add(NumberToTextConverter.toText(cdr.getNumericCellValue()));
						}
						
					}
					
					 
					 
					 
					 
					 
					 
				 }
				 
				 
			}
			 
			 
			 
				
				
			}
			   
			         
			 
			 
		 }
		
		
		
		
		
		
		System.out.println(list);
		
		System.out.println(list.get(0));
		System.out.println(list.get(1));
		System.out.println(list.get(2));
		System.out.println(list.get(3));
		
		
		
		
		
		
		

	}

}
