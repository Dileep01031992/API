import java.io.IOException;
import java.util.ArrayList;

public class sampletest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		
		
		Datadriven2 data= new Datadriven2();
		
	ArrayList<String> lm=	data.getdata("Rakesh");
	
	//lm.get(0);
	System.out.println(lm.get(0));
	System.out.println(lm.get(1));
	System.out.println(lm.get(2));
	System.out.println(lm.get(3));
	System.out.println(lm.get(4));
		
		

	}

}
