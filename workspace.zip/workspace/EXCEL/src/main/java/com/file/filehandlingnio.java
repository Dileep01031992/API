package com.file;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Iterator;
import java.util.List;

public class filehandlingnio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String path="D:\\H DRIVE\\New Volume\\Selenium2022\\Dileeptxt.txt";
		
		try {
		List<String> list=	Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8);
		
		Iterator<String> itr=list.iterator();
		int temp=0;
		
		while(itr.hasNext()) {
			
			String abc=itr.next();
			
			System.out.println(abc);
			
			
			if(abc.equals("Hobby")) {
				
				temp++;
			}
			
			
		}
	
		System.out.println(temp);	
		} catch (IOException e) {
			
			
			
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		

	}

}
