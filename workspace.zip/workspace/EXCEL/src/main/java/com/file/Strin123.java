package com.file;

public class Strin123 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String sr= "Dileep kumar  testing";
		
		String abc=sr.replace(" ", "");
		
		System.out.println(abc);
		
		
	}

}
