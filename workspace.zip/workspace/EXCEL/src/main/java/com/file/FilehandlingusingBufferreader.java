package com.file;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FilehandlingusingBufferreader {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedReader br=null;
		
		
		String path="D:\\H DRIVE\\New Volume\\Selenium2022\\Dileeptxt.txt";
		
		
	try {
		
		File file= new File(path);
		
		br= new BufferedReader(new FileReader(file));
		
		int c=0;
		//int temp=0;
		while((c=br.read())!=-1) {
			
			
			System.out.print((char)c);
			
			
		}
		
		//System.out.println(temp);
		
	}
		
	
	
		catch(Exception e) {
			
			e.printStackTrace();
		}
		
		
		finally {
			
			
			try {
				br.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		
		
		
		
		
		
		

	}

}
