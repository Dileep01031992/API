import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Datadriven2 {

	
	
	public ArrayList<String> getdata(String name) throws IOException {
		
ArrayList<String > list= new ArrayList<String>();
		
		File fis= new File("D:\\H DRIVE\\New Volume\\Selenium2022\\TestData\\Datadriven.xlsx");
		
		FileInputStream abc= new FileInputStream(fis);
		
		
		XSSFWorkbook book = new XSSFWorkbook(abc);
		
		
	int a=	book.getNumberOfSheets();
	
	System.out.println(a);
	
	for(int i=0;i<a;i++) {
		
		if(book.getSheetName(i).equalsIgnoreCase("testData")) {	
		XSSFSheet sheet=	book.getSheetAt(i);
		//Identify Testcases column by 	scanning the entire 1st row
		
		       Iterator<Row>  row=   sheet.rowIterator();//sheet is collection of row
		       
		     Row firstrow= row.next();
		     
		 Iterator<Cell> cell=    firstrow.cellIterator();
		 int k=0;
		 int column=0;
		 while(cell.hasNext()) {
			 
			Cell value= cell.next();
			
		if(value.getStringCellValue().equalsIgnoreCase("Name")) {
			
			
			column=k;
			
		}
		
		k++;
			 
			 
		 }
		 
		 
		System.out.println(column);
		
		//Once column is identified then scan entire testcases column to identify Rakesh test Row
		
		while(row.hasNext()) {
			
			Row rs=row.next();
			
	            if(rs.getCell(column).getStringCellValue().equalsIgnoreCase(name)) {
	            	
	            	Iterator<Cell> cls=rs.cellIterator();
	            	
	            	while(cls.hasNext()) {
	            		Cell c= cls.next();
	            		if(c.getCellType()==CellType.STRING) {
	            			
	            			c.getStringCellValue();
	            			list.add(c.getStringCellValue());
	            			
	            		}
	            		
	            		
	            		
	            		
	            		else {
	            			
	            			c.getNumericCellValue();
	            			
	            			
	            			NumberToTextConverter.toText(c.getNumericCellValue());
	            			
	            			list.add(NumberToTextConverter.toText(c.getNumericCellValue()));
	            		}
	            	}
	            	
	            	
	            	
	            }
	
	
			
			
			
			
		}
		
		
		
		
		
			
		}
		
		
		
		
	}
	
	
	
		
		
		return list;
		

		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
