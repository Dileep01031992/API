package Array;

public class Oned {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		int a[]= {12,23,45,27};
		int size=a.length;
		System.out.println(size);
		
		for(int i=0;i<=a.length-1;i++) {
			System.out.println(a[i]);
		}

	}

}
