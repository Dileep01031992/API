package Array;

public class missingnumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int [] a= {1,2,4,5,6};
		int expected_no_elements=a.length+1;
		
		System.out.println(expected_no_elements);
		
		int total_sum=expected_no_elements*(expected_no_elements+1)/2;
		System.out.println(total_sum);
		
		int sum=0;
		for(int i=0;i<a.length;i++) {
			
			sum=sum+a[i];
		}
		
		
		System.out.println("Missing no is "+(total_sum-sum));
		
		

	}

}
