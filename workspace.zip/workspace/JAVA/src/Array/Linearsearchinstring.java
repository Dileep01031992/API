package Array;

import java.util.Scanner;

public class Linearsearchinstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s[]= {"Dileep","Vivek","Raesh","DON","RAMU","SHYAM"};
		Scanner sh= new Scanner(System.in);
		
		System.out.println("Enter the String for Search");
		String item=sh.next();
		
		int temp=0;
		for(int i=0;i<s.length;i++) {
			
			if(s[i].equals(item)) {
			
			System.out.print(item+" Index is :"+i);
			temp=temp+1;
			
		}
		
		
		
		
			
	}

		if(temp==0) {
			System.out.println("Item not found");
		
		}
	}
}
