package Array;

public class Sumof2element {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int arr[]= {1, 2, 3, 5,1,2,2,8,-4};
		
		//How can I find two elements in an array that sum to k
		//Count pairs with given sum | Array
		//https://www.youtube.com/watch?v=0VHC1KVHH0U
		//https://www.youtube.com/watch?v=JBDS8Dc2sBw
		
		
		for(int i=0;i<arr.length;i++) {
			
			for(int j=i+1;j<arr.length;j++) {
				
				
				if(arr[i]+arr[j]==6) {
					
					System.out.println(arr[i]+" "+arr[j]);
				}
			}
			
			
			//System.out.println("abc");	
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
