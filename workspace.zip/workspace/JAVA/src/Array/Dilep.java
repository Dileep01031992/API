package Array;

public class Dilep {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
