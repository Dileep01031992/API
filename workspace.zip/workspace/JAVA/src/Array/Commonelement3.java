package Array;

import java.util.HashSet;

public class Commonelement3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int arr1[]= {10,20,40,30,40,50};
		int arr2[]= {30,70,80,10,10,90};
		
		HashSet<Integer> hs1=new HashSet<Integer>();
		HashSet<Integer>hs2=new HashSet<Integer>();
	
		
		
		for(int no:arr1) {
			hs1.add(no);
			//System.out.println(hs1);
		}
		
		for(int no:arr2) {
			hs2.add(no);
			//System.out.println(hs2);
		}
		
		for(int no:hs2) {
			
		Boolean b=	hs1.add(no);
		if(b==false) {
			System.out.print(no+" ");
		}
		
		}
		
		

	}

}
