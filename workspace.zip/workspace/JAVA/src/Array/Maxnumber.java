package Array;

public class Maxnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		int []a= {24,56,34,2,4,3,5};
		
		
		int max=a[0];
		
		for(int i=1;i<a.length;i++) {
			
			if(max<a[i]) {
				
				max=a[i];
			}
			
	
		}
		System.out.println(max);

	}

}
