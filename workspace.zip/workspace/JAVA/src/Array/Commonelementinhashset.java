package Array;

import java.util.HashSet;

public class Commonelementinhashset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int[]arr1= {4,3,7,9,2};
		int []arr2= {5,1,4,4,8,3};
		
		HashSet<Integer> hs=new HashSet<>();
		
		for(int no:arr1) {
			
			hs.add(no);
		}
		for(int no:arr2) {
			
			boolean b=hs.add(no);
			if(b==false) {
				System.out.print(no+" ");
			}
		}
		
		
		
		
		
		

	}

}
