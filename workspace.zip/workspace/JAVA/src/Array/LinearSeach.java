package Array;

import java.util.Scanner;

public class LinearSeach {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a[]= {10,30,50,70,90,20};
		
		
		
		Scanner s=new Scanner(System.in);
		System.out.println("Print a number for Search");
		int item=s.nextInt();
		
	
		int temp=0;
		for(int i=0;i<a.length;i++) {
			
			
			if(item==a[i]) {
				System.out.print(item+"Index"+i);
				temp=temp+1;
			}
			
			
		}
		if(temp==0) {
			System.out.println("Item is not available");
		}
		
		
		
		
		

	}

}
