package Array;

public class Commonelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a[]= {10,20,30,40,20,50};
		int b[]= {60,70,80,10,20,90};
		
		for(int i=0;i<a.length;i++) {
			
			for(int j=0;j<b.length;j++) {
			
				if(a[i]==b[j]) {
					
					System.out.print(a[i]+" ");
				}
				
			}
			
		}
		
		
		
		

	}

}
