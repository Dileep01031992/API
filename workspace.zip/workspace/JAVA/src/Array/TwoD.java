package Array;

public class TwoD {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a[][]= {{1,2,4},{56,78,57},{25,98,45}};
		
		for(int[] x:a) {
			
			for(int y:x) {
				System.out.println(y+" ");
			}
		}
		
		
		
		

	}

}
