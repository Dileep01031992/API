package Array;

public class twodforoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[][]= {{23,12,21,40},{34,65,76},{22,11,33}};
		
		int len=a.length;
		System.out.println(len);
		
		for(int i=0;i<a.length;i++) {
			
			for(int j=0;j<a[i].length;j++) {
				
				System.out.print(a[i][j]+" ");
			}
			
			System.out.println();
		}
		
		
		
		
		
		

	}

}
