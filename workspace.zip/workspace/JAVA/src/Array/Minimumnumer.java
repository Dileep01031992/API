package Array;

public class Minimumnumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int []a= {12,34,23,22,54,2};
		int min=a[0];
		
		for(int i=1;i<a.length;i++) {
			
			if(min>a[i]) {
				
				min=a[i];
			}
		}
		
		System.out.println(min);
		

	}

}
