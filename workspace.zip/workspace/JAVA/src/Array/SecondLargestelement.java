package Array;

public class SecondLargestelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int []a = {24,65,25,28,36};
		
		int temp=0;
		
		for(int i=0;i<a.length;i++) {
			
			for(int j=0;j<a.length-1-i;j++) {
				
				if(a[j]< a[j+1]) {
					
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
				
			}
			
		}
		
		for(int i=0;i<a.length;i++) {
			
		System.out.print(a[i]+" ");
			//System.out.print("Second largest element"+a[1]+" ");
			
		}
		
		System.out.print("Second largest element"+a[1]+" ");
	}

}
