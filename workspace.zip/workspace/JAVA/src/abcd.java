import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;


public class abcd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	String a="Dileep kumar Automation testing";
	
	
	char[] ch=a.toCharArray();
	
	
	HashMap<Character,Integer> hs= new HashMap<Character,Integer>();
	
	
	
	for(char c:ch) {
		
		if(hs.get(c)!=null) {
			
			
			hs.put(c, hs.get(c)+1);
			
			
			
		}
		
		else {
			
			hs.put(c, 1);
			
		}
		
	}
	
	
	
	
	hs.entrySet()
	
	
	
	
	
	
		
		
		
				
	}	
}
