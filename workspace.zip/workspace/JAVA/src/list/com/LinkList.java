package list.com;

import java.util.ArrayList;
import java.util.LinkedList;

public class LinkList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		//LinkList hs= new LinkList();
		//ArrayList<String> h1s= new ArrayList<String>();
		
		
		LinkedList hs= new LinkedList();
		
		hs.add("Dileep");
		hs.add("Eileep");
		hs.add("Fileep");
		hs.add("Gileep");
		hs.add("Hileep");
		
		System.out.println(hs);
		
		
		
		
		
		
		
		
		
		
	
		
		

	}

}
