package list.com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Addlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

		
		List list=new ArrayList();
		
		
		System.out.println(list.isEmpty());
		list.add("Dileep");
		//list.add(null);
		list.add("Rakesh");
		list.add("Vivek");
		list.add("Sandeep");
		list.add("Computer");
		
		System.out.println(list);
		
		list.equals("Dileep");
		System.out.println(list.contains("Rakesh"));
		Iterator itr= list.iterator();
		while(itr.hasNext()) {
			
			System.out.println(itr.next());
			
		//	itr.next().equals("Rakesh");
			
			
		}
	
		
		
		
		
Collections.sort(list);
System.out.println(list);
Collections.reverse(list);
System.out.println(list);
Collections.max(list);
System.out.println(list);
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
