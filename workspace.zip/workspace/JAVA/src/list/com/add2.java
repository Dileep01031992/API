package list.com;

import java.util.ArrayList;
import java.util.Collections;

public class add2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		ArrayList ls=new ArrayList();
		
		ls.add(100);
		ls.add(200);
		ls.add(300);
		ls.add(400);
		ls.add(500);
		ls.add(600);                                                                                                                                                          
		
		int y=Collections.binarySearch(ls,600);
		System.out.println(y);
		
		

	}

}
