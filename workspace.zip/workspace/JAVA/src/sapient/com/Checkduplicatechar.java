package sapient.com;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Checkduplicatechar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        
		String str="aaabbccdef";
		
		  char [] hr= str.toCharArray();
		  
		  HashMap<Character,Integer> map=new HashMap<Character,Integer>();
		  
		  for(Character m:hr) {
			  
			  if(map.get(m)!=null) {
				  
				  
				  map.put(m, (map.get(m)+1));
				  
			  }
			  
			  else {
				  map.put(m, 1);
			  }
			  
			  
		  }
		
		System.out.println(map.entrySet());
		System.out.println(map.keySet());
		System.out.println(map.values());
		
	Set<Entry<Character,Integer>>entr=	map.entrySet();
	
	Iterator<Entry<Character,Integer>> itr=entr.iterator();
	
	   while(itr.hasNext()) {
		   
		 Entry<Character,Integer> entry=  itr.next();
		 
		Character key= entry.getKey();
		Integer intr=entry.getValue();
		//System.out.print(""+key);
		//System.out.print(""+intr);
		
		if(entry.getValue()>1) {
			System.out.print(" "+entry.getKey());
		}
		
	   }
	
		
		    
		  
		  
		
	}

}
