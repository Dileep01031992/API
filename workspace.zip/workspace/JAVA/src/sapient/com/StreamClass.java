package sapient.com;

import java.util.Arrays;
import java.util.List;

public class StreamClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		                       List<Integer> hs=Arrays.asList(10,15,100,8,49,25,98,32);
		                       hs.stream().map(s->s +"")
		                       .filter(s->s.startsWith("1")).forEach(s->System.out.println(s));
		
		
		
		
	}

}
