package sapient.com;

public class Stringispanidrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String sr1="radar";
		String rev="";
		
		int len=sr1.length();
		
		for(int i=len-1;i>=0;i--) {
			
			rev=rev+sr1.charAt(i);
			
			
		}
		System.out.println("Reverse string is "+rev);	
		
		if(rev.equals(sr1)) {
			
			System.out.println("String is Palindrome "+ rev);
		}
		else {
			
			System.out.println("String is not a Palindrome "+rev);
		}

	}

}
