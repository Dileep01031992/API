package sapient.com;

public class Minmaxpair {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           String re="abb*&cde+fg";
           String result=Minmaxpair.Reversestrig(re);
		
           System.out.println(result);
		
	}

	public static String  Reversestrig(String rev) {
		
		char []ch=rev.toCharArray();
		
		for(int i=0,j=rev.length()-1;i<j;) {
			
			
			if(checkalphanmerical(ch[i])&&checkalphanmerical(ch[j])) {
				char temp=ch[i];
				ch[i]=ch[j];
				ch[j]=temp;
			     i++;
			     j--;
				
			}
			
			else if(!checkalphanmerical(ch[i])) {
				
				i++;
			}
			
			else if(!checkalphanmerical(ch[j])) {
				
				j--;
			}
			
			
		}
			
		return String.valueOf(ch);	
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	public static boolean checkalphanmerical(char ch) {
		
		return (ch >=48 && ch<=57)||(ch>=65 && ch<=97)||(ch>=97&&ch<=122);
	}
	
}
