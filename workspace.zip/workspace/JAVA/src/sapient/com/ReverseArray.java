package sapient.com;

import java.util.ArrayList;
import java.util.Collections;

public class ReverseArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Integer> list= new ArrayList<Integer>();
		
		list.add(12);
		list.add(35);
		list.add(1);
		list.add(10);
		list.add(34);
		list.add(1);
		
		System.out.println(list);
		
		
		Collections.reverse(list);
		
		System.out.println(list);
		Collections.sort(list);
		System.out.println(list);
		int a=Collections.binarySearch(list, 12);
		System.out.println(a);
		int max=Collections.max(list);
		System.out.println("Maximum value is "+max);
		int min=Collections.min(list);
		System.out.println("Minimum value is "+min);
		
		
		
		
		

	}

}
