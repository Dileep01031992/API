package sapient.com;

public class Integerpalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int no=123;
		int n2=no;
		int rev=0;
		int rem;
		
		while(n2!=0) {
			
			rem=n2%10;
			rev=rev*10+rem;
			n2=n2/10;
			
			
		}
		
		
		if(rev==no) {
			System.out.println("Number is palindrome"+no);		
			}
		else {
			System.out.println("Number is not palindrome");
		}
		
		
		
		
		

	}

}
