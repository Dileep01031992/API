import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;



public class Sringm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String sr="My name is Dileep My name is Dileep My name is Dileep";
		
		String []sr2=sr.split(" ");
		
		
		HashMap<String , Integer > hs= new HashMap<String, Integer>();
		
		 for(String ms:sr2) {
			 
			 if(hs.get(ms)!=null) {
				 
				 hs.put(ms, hs.get(ms)+1);
				 
			 }
			 
			 
			 
			 else {
				 
				 hs.put(ms, 1);
				 
			 }
		 }
		
		
		 
		 Set<Entry<String,Integer>> ent= hs.entrySet();
		 
	      Iterator<Entry<String,Integer>> itr=ent.iterator();
	      
	      
	      while(itr.hasNext()) {
	    	  
	    	  Entry<String,Integer> eny=itr.next();
	    	  
	    	  System.out.print(" "+eny.getKey()+" "+eny.getValue());
	    	  
	    	  
	      }
		
		
		
		
		 
		 
		 
		 
		
		
		
			
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	

}
