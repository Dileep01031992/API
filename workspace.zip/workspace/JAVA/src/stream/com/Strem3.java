package stream.com;

import java.util.ArrayList;

public class Strem3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		
		list.add(10);
		list.add(15);
		list.add(8);
		list.add(49);
		list.add(25);
		list.add(98);
		list.add(32);
		
	//	list.stream().map(s->s+" ").filter(s-> s.startsWith("1")).forEach(s->System.out.println(s));
		
		
		
		
		
		
		

	}

}
