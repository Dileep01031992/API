package stream.com;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Findduplicateelement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		  List<Integer> hs=Arrays.asList(10,15,15,100,8,49,25,98,32);
		  
		
		  Set<Integer> dup=  hs.stream().filter(s->Collections.frequency(hs, s)>1).collect(Collectors.toSet());
		  System.out.println(dup);
	}

}
