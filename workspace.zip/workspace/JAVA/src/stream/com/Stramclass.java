package stream.com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class Stramclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		ArrayList<String> arr=new ArrayList<String>();
		
		arr.add("Abhijeet");
		arr.add("Don");
		arr.add("Alekhya");
		arr.add("Adam");
		arr.add("Ram");
		
	long g=	arr.stream().filter(s -> s.startsWith("A")).count();
	System.out.println(g);
	
	
	//there is no file intermediate option if there is no terminal option
	//terminal operation will be execute only if inter op(filter) returns true
	//we can crate stream
	//how to use filter in stream API
	
	
	long m=Stream.of("Abhijeet","Don","Alekhya","Adam","Ram").filter(s->
	{
		s.startsWith("A");
		return true;
		
	}).count();
	System.out.println(m);
arr.stream().filter(s-> s.length()>4).forEach(s->System.out.println(s));	
arr.stream().filter(s->s.length()>4).limit(1).forEach(s->System.out.println(s));



/* print name which have last letter as "a" with upper case*/

Stream.of("Abhijeet","Don","Alekhya","Adam","Rama").filter(s->s.endsWith("a")).map(s->s.toUpperCase())
	.forEach(s->System.out.println(s));
	
/*print names which have first letter as a with uppercase and sorted */

    List<String> fames=Arrays.asList("Abhijeet","Don","Alekhya","Adam","Rama");
    
    fames.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.print("" +s));





	
	
	
	
	
	
	
		
		
		
		

	}

}
