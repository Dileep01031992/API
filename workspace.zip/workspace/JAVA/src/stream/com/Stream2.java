package stream.com;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Stream2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		/*print names which have first letter as a with uppercase and sorted */

		    List<String> fames=Arrays.asList("Abhijeet","Don","Alekhya","Adam","Rama");
		    
		    fames.stream().filter(s->s.startsWith("A")).sorted().map(s->s.toUpperCase()).forEach(s->System.out.print(" " +s));

		    
	
		    //Merging 2 different list
		    
		    ArrayList<String> arr1=new ArrayList<String>();
		    
		    arr1.add("man");
		    arr1.add("Don");
		    arr1.add("women");
		    
	List<String> arr2=	    Arrays.asList("Abhijeet","Don","Alekhya","Adam","Rama");
	
Stream<String> newstream=	Stream.concat(arr1.stream(), arr2.stream());

//newstream.forEach(s->System.out.println(s));

//newstream.sorted().forEach(s->System.out.print(" " +s));
		    
		    
	


//print the value match with

boolean flag=newstream.anyMatch(s->s.equalsIgnoreCase("Adam"));
System.out.println(flag);



//Streamcollector
 List<String>ls=Stream.of("Dieep","Deepak","Ansul","Arunav","Apun").filter(s->s.endsWith("k")).map(s->s.toUpperCase()).collect(Collectors.toList());
System.out.println(ls.get(0));


//print unique number from array

List<Integer> values=Arrays.asList(3,2,2,7,5,1,9,7);

values.stream().distinct().forEach(s->System.out.println(s));


List<Integer> valueswe=Arrays.asList(3,2,2,7,5,1,9,7);

List<Integer> an=valueswe.stream().distinct().sorted().collect(Collectors.toList());
System.out.println("Index is  "+an.get(2));











		    
		    
		    
		    
		    
		    
		    
		    
		    


	}

}
