package set.com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;

public class Removeduplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s="aabbcc";
		
	char ch[]=	s.toCharArray();
	
	HashSet<Character> hs= new HashSet<Character>();
	
	
	for(char n:ch) {
		
		
		hs.add(n);
	}
	
	  Iterator<Character> itr= hs.iterator();
	  
	  while(itr.hasNext()) {
		  
		  System.out.print(itr.next()+"");
	  }
		//ArrayList<Character> al= new ArrayList<Character>(hs);
		//System.out.println(al);
		
		//Collections.reverse(al);
	//	System.out.println(al);
		
		
		

	}

}
