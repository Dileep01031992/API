package set.com;

import java.util.HashSet;

public class Hshset {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashSet<Integer> hS = new HashSet<Integer>();
		
		hS.add(3);
		hS.add(4);
		hS.add(5);
		hS.add(6);
		hS.add(7);
		hS.add(8);
		hS.add(8);
		hS.add(8);
		hS.add(8);
		
		
		Integer [] arr= new Integer[hS.size()];
		
		hS.toArray(arr);
		
	int a=	arr.length;
	
	int temp=0;
	
	System.out.println(hS.size());
	System.out.println(a);
	
	
	for(int i=0;i<a;i++) {
		
		for(int j=0;j<a-1-i;j++) {
			
			if(arr[j]>arr[j+1]) {
				
				temp=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=temp;
				
			}
			
			
			
			
		}
		
		
	}
		
		
		
		
 for(int i=0;i<arr.length;i++) {
	 
	 
	 System.out.print(" "+arr[i]);
 }
		
		
		
		
		
		
		
		
		
		

	}

}
