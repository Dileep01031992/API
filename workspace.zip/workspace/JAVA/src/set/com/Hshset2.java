package set.com;

import java.nio.file.FileVisitResult;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

public class Hshset2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//HashSet<Integer> hS = new HashSet<Integer>();
		ArrayList<Integer> hS= new ArrayList<Integer>();
		hS.add(3);
		hS.add(4);
		hS.add(5);
		hS.add(6);
		hS.add(7);
		hS.add(8);
		hS.add(8);
		hS.add(8);
		hS.add(8);
		
		  System.out.println(hS);
		  
		  
		Iterator<Integer>  itrIterator= hS.iterator();
		
		while(itrIterator.hasNext()) {
			
			
			itrIterator.next();
			
			System.out.print(itrIterator.next());
			
			
		}
		  
		  
		  
		  
		  
		  
	

			
			
		
		
	
		
		
		
		
		
		
		
		
		
		

	}

}
