package abc;

public class ReverseAstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String abc="Dileep";
		String rev=" ";
		int len=abc.length();
		System.out.println(len);
		
		for(int i =0;i>=abc.length();i--) {
			
			System.out.println(charAt(i));
			
		}
		
			
		System.out.println(rev);
		
		

	}

	private static char[] charAt(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
