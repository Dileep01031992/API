package abc;

public class ReverseAnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		int nub=121;
		int temp=nub;
		int rev=0;
		int rem;
				
		while(temp!=0) {
			
			rem=temp%10;
			rev=rev*10+rem;
			temp=temp/10;
			
		}
		
		if(nub==rev) {
			System.out.println("Number is Palindrome "+nub);
		}
		else {
			System.out.println("Number is not palindrome "+nub);
		}
	}

}
