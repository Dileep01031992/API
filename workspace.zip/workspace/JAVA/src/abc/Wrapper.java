package abc;

public class Wrapper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Valueof()-> change the primive to wrapper
		
		Integer I=Integer.valueOf("10");
		System.out.println(I);
		
		Boolean b=Boolean.valueOf("Durga");
		
		System.out.println(b);
		
		//xxxValue to get primitive for the given wrapper object
		
		Integer L=new Integer(130);
		System.out.println(L.intValue());
		System.out.println(L.floatValue());
		
		
		//parse convert string to primitive
		
		
		int i=Integer.parseInt("10");
		System.out.println(i);
		boolean m=Boolean.parseBoolean("true");
		System.out.println(m);
		
		
		
		//tostring convert primitive or object to string
		Integer k=new Integer(200);
		
		System.out.println(k.toString().charAt(0));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
