package abc;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Datedonot {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		Date date=new Date();
		
		System.out.println(date);
		
		System.out.println(date.getClass());
		
		SimpleDateFormat format= new SimpleDateFormat("yyyy-MM-dd");
		//SimpleDateFormat timeformat = new SimpleDateFormat("yyyy/MM/dd:hh:mm:ss");
		
	String dn=	format.format(date);
	System.out.println(dn);
	
		
		

	}

}
