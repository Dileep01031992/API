package abc;

public class fobo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		
		String abc="Dileep";
		String rev=" ";
		int len=abc.length();
		System.out.println(len);
		
		for(int i=len-1;i>=0;i--) {
			
			rev=rev+abc.charAt(i);
			
			
		}
		System.out.println(rev);
		
		Boolean c=abc.equalsIgnoreCase(rev);
		System.out.println(c);
		
		
		
		

	}

	private static char[] charAt(int i) {
		// TODO Auto-generated method stub
		return null;
	}

}
