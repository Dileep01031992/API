package practice;

public class reverseaword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String sr1="This Is Dileep";
		
		String [] sr2=sr1.split(" ");
		String rev="";
		
		for(String w:sr2) {
			
			
			String revin="";
			
			
			for(int i=w.length()-1;i>=0;i--) {
				
				
				revin=revin+w.charAt(i);
				
				
				
				
			}
			
			
			rev=rev+revin+" ";;
			
			
		}
		
		
		System.out.println(rev);
		
		
		
		
		

	}

}
