package practice;

public class Reverseastringwithspecial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String abc="%Dileep+@#kumar&";
		
		String result=Reverseastringwithspecial.reverseastring(abc);
		System.out.println(result);
		
		
	}
	
	
	public static String reverseastring(String sr1) {
		
		
		char [] chr=sr1.toCharArray();
		
		for(int i=0,j=sr1.length()-1;i<j;) {
			
			
			
			if(albhabet(chr[i])&& albhabet(chr[j])) {
				
				char temp=chr[i];
				chr[i]=chr[j];
				chr[j]=temp;
				i++;
				j--;
				
				
				
			}
			
			
			else if(!albhabet(chr[i])) {
				
				i++;
			}
			
		
			else if(!albhabet(chr[j])) {
				j--;
			}
			
		}
		
		
		
		return String.valueOf(chr);
	}
	
	
	
	
	
	
	public static boolean albhabet(char ch) {
		
		
		return (ch>=48&&ch<=57)||(ch>=65&&ch<=96)||(ch>=97&&ch<=122);
		
		
	}
	
	
	

}
