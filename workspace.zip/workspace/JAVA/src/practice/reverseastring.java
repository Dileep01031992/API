package practice;

public class reverseastring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String src= "radar";
		
		String rev="";
		
		
		for(int i=src.length()-1;i>=0;i--) {
			
			
			rev=rev+src.charAt(i);
			
		}
		
		
		System.out.println(rev);
		
		
		
		if(rev.equals(src)) {
			
			System.out.println("String is Palindrome "+rev+" "+src);
			
		}
		
		else 
		{
			System.out.println("String is not palindrome "+rev+" "+src);
		}

	}

}
