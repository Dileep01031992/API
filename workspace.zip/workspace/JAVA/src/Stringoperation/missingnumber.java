package Stringoperation;

import java.util.HashSet;
import java.util.Set;

public class missingnumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int start =1;
		int end=100;
		
		int []arr= {2,4,5};
		
		Set<Integer> missingnumbr=new HashSet<Integer>();
		
		for(int i=start;i<=end;i++) {
			
			boolean status=false;
			
			
			for(int j=0;j<arr.length;j++) {
				
				if(i==arr[j]) {
					
					status=true;
					break;
				}
				
				
			}
			
			
			if(status==false) {
				missingnumbr.add(i);
			}
			
		}
		
		
		
	System.out.println(missingnumbr);
		

	}

}
