package Stringoperation;

public class FirstLowercase223 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String sr="this is dileep";
		
		String sr2=" "+sr;
		
		String f="";
		
		System.out.println(sr2);
		
		
		for(int i=0;i<sr2.length();i++) {
			
			char ch=sr2.charAt(i);
			
			if(ch==' ') {
				
				f=f+ch;
				i++;
				
				
				ch=sr2.charAt(i);
				
				f=f+Character.toUpperCase(ch);
				
			}
			
			else {
				
				f=f+ch;
			}
			
			
			
			
			
		}
		
		f=f.trim();
		System.out.println(f);
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
