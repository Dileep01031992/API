package Stringoperation;

public class Specialcharacter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String email="Dileep499689@gmail.com";
		
		StringBuffer character1=new StringBuffer();
		StringBuilder nubber=new StringBuilder();
		StringBuilder special=new StringBuilder();
		StringBuilder Lower=new StringBuilder();
		StringBuilder upper=new StringBuilder();
		
		
		for(int i=0;i<=email.length()-1;i++) {
			
			char ch=email.charAt(i);
			
			//System.out.println(ch);
			
			if(Character.isLetter(ch)) {
				character1.append(ch);
				
				if(Character.isLowerCase(ch)) {
					Lower.append(ch);
				}
				else if(Character.isUpperCase(ch)) {
					upper.append(ch);
				}
			}
			else if(Character.isDigit(ch)){
				nubber.append(ch);
			}
			
			else {
				special.append(ch)	;
			}
			
			
		}
		
		System.out.println("Character are "+character1);
		System.out.println("Number are "+nubber);
		System.out.println("Special character are "+special);
		System.out.println("Lower case are "+Lower);
		System.out.println("Upper case are "+upper);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

	private static void elseif() {
		// TODO Auto-generated method stub
		
	}

}
