package Stringoperation;

public class Removewhitespace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String str = "India     Is My    Country";  
        //1st way  
        String noSpaceStr = str.replaceAll("\\s", ""); // using built in method  
        System.out.println(noSpaceStr);  
	}

}
