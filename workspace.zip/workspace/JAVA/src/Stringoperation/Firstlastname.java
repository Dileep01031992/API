package Stringoperation;

public class Firstlastname {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String str="Dileep kumar";
		
		String[] str2=str.split(" ");
		
		for(int i=str2.length-1;i>=0;i--) {
			
			
			System.out.print(str2[i]+" ");
			
		}
		
		
		
		

	}

}
