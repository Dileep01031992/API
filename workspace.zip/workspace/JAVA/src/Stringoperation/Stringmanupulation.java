package Stringoperation;

public class Stringmanupulation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s1="dileep"; String s2="dileep"; 
		System.out.println(s1.concat(s2));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
