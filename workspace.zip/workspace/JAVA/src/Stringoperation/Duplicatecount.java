package Stringoperation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Duplicatecount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String word="I am qa engineer in wipro digital digital @@ @@";
		
		HashMap<String,Integer> m= new HashMap();
		String wordinarr[]=word.split(" ");
		
		for(String qa :wordinarr ) {
			
			if(m.get(qa)!=null) {
				
				 m.put(qa,m.get(qa)+1);
			}
			
			else {
				m.put(qa,1);
			}
			
			
		}
		
		
		System.out.println(m);
		
	Set s=	m.keySet();
	System.out.println("Key set view of collectuons"+s);
	Set<Entry<String,Integer>> sc=m.entrySet();
	System.out.println("Set of entry "+sc);
	
	Iterator<Entry<String,Integer>> itr=sc.iterator();
	while(itr.hasNext()) {
		Entry<String,Integer> entry=itr.next();
		if(entry.getValue()>1) {
			System.out.println(entry.getValue()+" "+entry.getKey());
		}
		
		
		
	}
	
	
	
		
		
		
		
		
		
		
		
		
		
		

	}

}
