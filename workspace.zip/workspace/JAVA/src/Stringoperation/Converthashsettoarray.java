package Stringoperation;

import java.util.HashSet;

public class Converthashsettoarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashSet<Integer> hs= new HashSet<Integer>();
		
		hs.add(10);
		hs.add(20);
		hs.add(20);
		hs.add(30);
		hs.add(40);
		hs.add(50);
		hs.add(60);
		
	
		
		Integer [] a= new Integer[hs.size()];
		
		hs.toArray(a);
		int temp=0;
		for(int i=0;i<a.length;i++) {
			
			for(int j=0;j<a.length-1-i;j++) {
				
				if(a[j]<a[j+1]) {
					
					temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
					
					
					
				}
				
				
				
			}
			
			
		}
		
   for(int i=0;i<a.length;i++) {
	   
	   
	  // System.out.print(" "+a[i]);
	   System.out.println(" "+a[1]);
	   break;
   }
		
		
		
		
		
		
		

	}

}
