package Stringoperation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class CountduplicateinInteger {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] num= {12,13,35,32,12};
		
		HashMap<Integer,Integer> hm= new HashMap<Integer,Integer>();
		
		for(int n : num) {
			
			if(hm.get(n)!=null) {
				
				hm.put(n, hm.get(n)+1);
			}
			else {
				hm.put(n, 1);
			}
		}
		
		System.out.println(hm);
		
		
	Set<Entry<Integer,Integer>> s=	hm.entrySet();
	
	Iterator<Entry<Integer,Integer>> itr=s.iterator();
	
	while(itr.hasNext()) {
		
		Entry<Integer,Integer> entry=itr.next();
		if(entry.getKey()>1) {
			System.out.print(" "+entry.getKey()+" Comes "+ entry.getValue());
		}
		
	}
	
	
		
		
		

		
	}

}
