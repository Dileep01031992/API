package Stringoperation;

public class Reversestringspecial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="abc&*def*";
		
	String result=	reversespecialcase(str);
	
	System.out.println(result);
		

	}

	
	
	public static String reversespecialcase(String reverse) {
		
		
		char [] arr=reverse.toCharArray();
		
		
		for(int i=0,j=reverse.length()-1;i<j;) {
			
			
			
			if(charalphabet(arr[i])  && charalphabet(arr[j])) {
				
				char temp;
				
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
				
				
				
				i++;
				j--;
				
				
			}
			
			
			if(!charalphabet(arr[i])) {
				
				i++;
			}
			
          if(!charalphabet(arr[j])) {
				
				j--;
			}
			
			
		}
		
		return String.valueOf(arr);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static boolean charalphabet(char ch) {
		
		return (ch>=48 && ch<=57)||(ch>=65&& ch<=97)||(ch>=97&&ch<=122);
		
	}
	
	
	
	
}
