package Stringoperation;

public class FirstLowercase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String sr="this is dileep";
		
		String s2=" "+sr;
		
		String f="";
		
		System.out.println(s2);
		
		
		
		for(int i=0;i<s2.length();i++) {
			
			char ch =s2.charAt(i);
			
			if(ch==' ') {
				
				
				f=f+ch;
				
				i++;
				
				ch=s2.charAt(i);
				f=f+Character.toUpperCase(ch);
				
				
				
			}
			
			
			else {
				
				f=f+ch;
			}
			
		}
		
		
		f=f.trim();
		
		System.out.println(f);
		
		

	}

}
