package Stringoperation;

public class Firstuppercase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="this is dileep";
		
		String str2=" "+str;
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
