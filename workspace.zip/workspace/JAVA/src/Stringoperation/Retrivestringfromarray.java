package Stringoperation;

public class Retrivestringfromarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		String name[]= {"Dileep","Rakesh","Ramu"};
		
		System.out.println(name);
		
		for(int i=0;i<=name.length-1;i++) {
			
			System.out.println(name[i]);
			
			
			
		}
		
		for(String x:name) {
			System.out.println("Enhance loop "+x);
		}
		
		
		

	}

}
