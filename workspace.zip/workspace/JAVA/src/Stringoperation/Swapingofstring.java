package Stringoperation;

public class Swapingofstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String a="Hello";
		String b="World";
		
		System.out.println(a.length());
		System.out.println(b.length());
		
		System.out.println("Before swap"+a+" "+b);
		a=a+b;
		
		System.out.println(a);
		
		System.out.println(a.length());
		System.out.println(b.length());
		
		b=a.substring(0, a.length()-b.length());
		
		System.out.println(b);
		
		a=a.substring(b.length());
		
		System.out.println(a);
		
		System.out.println("After swap"+a+" "+b);
		
		
		
		
		
		
	}

}
