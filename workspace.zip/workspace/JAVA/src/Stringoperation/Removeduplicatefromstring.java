package Stringoperation;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class Removeduplicatefromstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String name="My name is Khan and I am not not terirest";
		
		String dat[]=name.split(" ");
	//	for(int i=0;i<=dat.length-1;i++) {
			//System.out.print(dat[i]);
		//}
		
		//declare the hashset
		LinkedHashSet<String> sh=new LinkedHashSet<String>();
		for(String x:dat) {
			sh.add(x);
		}
		
		Iterator<String> abc= sh.iterator();
		while(abc.hasNext()) {
			System.out.print(" "+abc.next());
		}
		
		
		
		
		
		
		
	}

}
