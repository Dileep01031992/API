package Stringoperation;

public class Reversestringexceptspecialchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		String abc= "Dileep@&&*kumar";
		String sr2=Reversestringexceptspecialchar.reversestring(abc);
		
		System.out.println(sr2);
	

	}
	
	
	
	public static String reversestring(String sr) {
		
		 char ch[]= sr.toCharArray();
		 
		 for(int i=0,j=sr.length()-1;i<j;) {
			 
			 
			 
			 if(alphabetchar(ch[i])&& alphabetchar(ch[j])) {
				 
				 char temp=ch[i];
				 ch[i]=ch[j];
				 ch[j]=temp;
				 
				 i++;
				 j--;
				 
			 }
			 
			 
			 
			  if(!alphabetchar(ch[i])) {
				
				 i++;
				 
				 
			 }
			 
			 
			  if(!alphabetchar(ch[j])) {
				 
				 j--;
			 }
			 
		 }
		 
		 return String.copyValueOf(ch);
		
		
	}
	
	
	
	
	
	
	
	public static boolean alphabetchar(char h) {
		
		
		return (h>=48 && h<=57)||(h>=65 && h<=97)||(h>=97 && h<=122);
		
	}
	
	
	
	
	
	
	

}
