package Stringoperation;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Countofduplicatechar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String name3="My name id Dileep Kumar";
		String name=name3.replaceAll("\\s", "");
		System.out.println(name);
		
		char ch[]=name.toCharArray();
		
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		
		for(Character s :ch) {
			
			if(hm.get(s)!=null) {
				hm.put(s, hm.get(s)+1);
			}
			else {
				hm.put(s, 1);
			}
		}
		
		
		System.out.println(hm);
		
		Set<Entry<Character,Integer>> rs=hm.entrySet();
		
		Iterator<Entry<Character,Integer>> itr= rs.iterator();
		
		while(itr.hasNext()) {
			
			Entry<Character,Integer> entry=itr.next();
			
			if(entry.getValue()>1) {
				System.out.println(entry.getValue()+" comes "+entry.getKey());
			}
		}
		
		
		
		
		
		
		
		
		
		
		

	}

}
