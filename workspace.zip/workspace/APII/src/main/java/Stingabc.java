import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

public class Stingabc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String abc=" This iS a tESt  ";
		 
		
		String[] sr2=abc.split(" ");
		String rev="";
		
		
		for(String hs:sr2) {
			
			String revin="";
			
			for(int i=hs.length()-1;i>=0;i--) {
				
				revin=revin+hs.charAt(i);
				
				
				
			}
			
			
			rev=rev+revin+" ";
			
			
			
		}
		
		
		
		
		System.out.println(rev);
		
		
		
		
		
		
		
		

	}

}
