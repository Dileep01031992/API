import java.util.ArrayList;
import java.util.HashSet;

public class string {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		HashSet<Integer> hs= new HashSet<Integer>();
		
	                 hs.add(2);
	                 hs.add(2);
	                 hs.add(3);
	                 hs.add(4);
	                 hs.add(5);
	                 hs.add(5);
	                 hs.add(6);
	                 hs.add(7);
	                 
	                 
	                 
	        ArrayList<Integer> lis=new ArrayList<Integer>(hs);
	        
	        System.out.println(lis);
	      Integer [] intarray= new Integer[lis.size()]; 
	       lis.toArray(intarray);
	        
	       
	        int temp=0;
	       
	       for(int i=0;i<intarray.length;i++) {
	    	   
	    	   for(int j=0;j<intarray.length-i-1;j++) {
	    		   
	    		   
	    		   if(intarray[j]<intarray[j+1]) {
	    			   
	    			   temp=intarray[j];
	    			   intarray[j]=intarray[j+1];
	    			   intarray[j+1]=temp;
	    			   
	    		   }
	    		   
	    		   
	    		   
	    	   }
	    	   
	    	   
	    	   
	    	   
	    	   
	    	   
	       }
	        
	        
	        
for(int i=0;i<intarray.length;i++) {
	    	   
	    	   System.out.print(" "+intarray[i]);
	    	     
	    	   
	       }
	        
	        
	        
	        
	        
	        
	        
		
		
		
		
		
		
		
		
		

	}

}
