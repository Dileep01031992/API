import static io.restassured.RestAssured.given;

import com.file.payload;
import com.pojo.Login;
import com.pojo.LoginResponse;

import io.restassured.RestAssured;
import io.restassured.RestAssured.*;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;

public class Endtoendapi {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//
		
		/*
		 * RestAssured.baseURI="https://rahulshettyacademy.com";
		 * 
		 * String request=
		 * given().log().all().header("Content-Type","application/json").body(payload.
		 * login()) .when().post("/api/ecom/auth/login")
		 * .then().assertThat().extract().response().asString();
		 */    
	
	
RequestSpecification res	=       new  RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").setContentType(ContentType.JSON)
.build();
	
Login log= new Login();
log.setUserEmail("rahulshetty@gmail.com");
log.setUserPassword("Iamking@000");

RequestSpecification reslog=given().log().all().spec(res).body(log);

LoginResponse loginresponse=reslog.when().post("/api/ecom/auth/login")
.then().extract().response().as(LoginResponse.class);

String token=loginresponse.getToken();

String userid=loginresponse.getUserId();

System.out.println(token);
System.out.println(userid);








	
		
		
	     
	
	
	
		

	}

}
