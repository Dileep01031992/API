import org.testng.Assert;
import org.testng.annotations.Test;

import com.file.payload;

import io.restassured.path.json.JsonPath;

public class sumvalidation {
	
	
	@Test()
	public void sumValidation() {
		
		/* 6. Verify if Sum of all Course prices matches with Purchase Amount */
		JsonPath js= new JsonPath(payload.Course());
		
	  int size=       js.get("courses.size()");
	  System.out.println(size);
	  
	  int sum=0;
	  for(int i=0;i<size;i++) 
	  {
		 int price=js.getInt("courses["+i+"].price"); 
		 System.out.println(price);
		 int copies=js.getInt("courses["+i+"].copies");
		 System.out.println(copies);
		 
		 int totalprice=price*copies;
		 
		  sum=sum+totalprice;
		  System.out.println(sum);
	  }
		
	int puchaseamt=	js.getInt("dashboard.purchaseAmount");
	System.out.println(puchaseamt);
	
	Assert.assertEquals(sum, puchaseamt);
	  
	  
	  
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	

}
