import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.file.payload;

import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import static io.restassured.RestAssured.*;

public class dynamicjson {
	
	
	
	
	@Test(dataProvider="addapibook")
	public void dynamicJson(String isbn,String aishle) {
		
		
	  RestAssured.baseURI="http://216.10.245.166";
	 
	  //GIVEN
	  
	 String response= given().header("Content-Type","application/json").log().all()
	  .body(payload.addlib(isbn, aishle))
	  
	  //When
	  
	  .when().post("/Library/Addbook.php")
	  
	  //Then
	  .then().assertThat().log().all().statusCode(200).extract().response().asString();
	  
	  
	  
	  
	  JsonPath js1= new JsonPath(response);
	       String srString=     js1.get("ID");
	  System.out.println(srString);
	  
	}
	
	@DataProvider(name="addapibook")
	public Object[][] getData() {
		
	return	new Object[][] {{"dileeep","76543"},{"dileeeep","98765"},{"dileeeeep","3456788"}};
		
		
	}
	
	
	

}
