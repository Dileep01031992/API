package com.pojo;

import java.util.List;

public class Courses {
	
 private List<WebAutomation> webAutomations;
 private List<API> api;
 private List<mobile> mobiles;

 public List<WebAutomation> getWebAutomations() {
	return webAutomations;
}
public void setWebAutomations(List<WebAutomation> webAutomations) {
	this.webAutomations = webAutomations;
}
public List<API> getApi() {
	return api;
}
public void setApi(List<API> api) {
	this.api = api;
}
public List<mobile> getMobiles() {
	return mobiles;
}
public void setMobiles(List<mobile> mobiles) {
	this.mobiles = mobiles;
}
 
 
 
	
	

}
