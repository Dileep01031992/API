import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertEquals;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.testng.Assert;

import com.file.payload;
public class Abc {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
  //to verify the Add API is working as expected
		//payload.addapi() using this instead of file
		String address="Ratu road ranchi";
		//given all input
		//when resource and http operation
		//then  validation condition
		//https://rahulshettyacademy.com//maps/api/place/add/json?key=qaclick123
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
	String responses=	given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
		.body(new String(Files.readAllBytes(Paths.get("H:\\API 2022\\file.json"))))
		.when().post("maps/api/place/add/json")
		      .then().assertThat().statusCode(200).body("scope", equalTo("APP")).header("Server", "Apache/2.4.41 (Ubuntu)").extract().response().asString();
		      
		//System.out.println("******************"+responses);  
		
		JsonPath path=new JsonPath(responses);
		
		String placeID=path.getString("place_id");//for parsing json
		
		
		System.out.println("******PlaceID**********"+placeID);
		
		
		//Update Place
		
		given().queryParam("key", "qaclick123").header("Content-Type","application/json")
		.body("{\r\n"
				+ "	\"place_id\": \""+placeID+"\",\r\n"
				+ "	\"address\" : \""+address+"\",\r\n"
				+ "	\"key\":\"qaclick123\"\r\n"
				+ "}\r\n"
				+ "")
		.when().put("maps/api/place/update/json")
		.then().assertThat().log().all().statusCode(200).body("msg",equalTo("Address successfully updated"));
		
		
		//To verify get is working as expected or not
		
String getresponse=	given().log().all().queryParam("key", "qaclick123").queryParam("place_id",placeID)
	.when().get("maps/api/place/get/json")
	.then().assertThat().log().all().statusCode(200).extract().response().asString();
	
	System.out.println(getresponse);
		
		JsonPath js2=new JsonPath(getresponse);
		String newaddress=js2.getString("address");
		System.out.println("*********************"+newaddress+"***************");
		Assert.assertEquals(address, newaddress);
		
		
		
				
		
		
	}

}
