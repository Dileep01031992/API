import com.file.payload;

import io.restassured.path.json.JsonPath;

public class Complexjsonpase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		JsonPath js=new JsonPath(payload.Course());
		
		/*1. Print No of courses returned by API*/	
	       int size=	js.getInt("courses.size()");
	           System.out.println(size);
				
	/*2.Print Purchase Amount*/
	           
	   int purchaseamount=        js.getInt("dashboard.purchaseAmount");
	   System.out.println(purchaseamount);
	           

	/*3. Print Title of the first course*/
	     String firstcoursetitle= js.get("courses[0].title");
	     
	     System.out.println("****First couse is  "+firstcoursetitle);

	/*4. Print All course titles and their respective Prices*/
	     
	     for(int i=0;i<size;i++) {
	    	 
	    	String title= js.get("courses["+i+"].title");
	    	int price=js.getInt("courses["+i+"].price");
	    	
	    	System.out.println("*****Title of Book "+title+"and price is "+price+"*********");
	     }
	     
	     

	/*5. Print no of copies sold by RPA Course*/
	     
	     for(int i=0;i<size;i++) {
	    	 
	    	 if(js.get("courses["+i+"].title").equals("RPA")) {
	    		 int sold=js.getInt("courses["+i+"].copies");
	    		 
	    		 System.out.println("*********Copies sold  "+sold);
	    		 break;
	    	 }
	    	 
	     }
	     
	     

	/* 6. Verify if Sum of all Course prices matches with Purchase Amount */


	}

}
