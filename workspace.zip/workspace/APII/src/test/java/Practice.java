import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import com.file.payload;

import io.restassured.RestAssured;
import io.restassured.RestAssured.*;
import io.restassured.path.json.JsonPath;

public class Practice {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		RestAssured.baseURI="https://rahulshettyacademy.com";
		
		
	String res=	given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
		.body(new String(Files.readAllBytes(Paths.get("D:\\H DRIVE\\New Volume\\API 2022\\file.json"))))
		.when()
		.post("maps/api/place/add/json")
		.then().assertThat().log().all().statusCode(200).extract().response().asString();
	
	
	JsonPath js= new JsonPath(res);
	
	     String Place_ID=    js.get("place_id");
	     
	     System.out.println(Place_ID);
	     
	     
	     
	     String address="Sydeny1234 Ratu 834001";
	     
	     //Update place
	     
	     given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json")
	     .body("{\r\n"
	     		+ "\"place_id\":\""+Place_ID+"\",\r\n"
	     		+ "\"address\":\""+address+"\",\r\n"
	     		+ "\"key\":\"qaclick123\"\r\n"
	     		+ "\r\n"
	     		+ "}")
	     .when()
	     .put("maps/api/place/update/json")
	     .then().assertThat().log().all().statusCode(200).body("msg", equalTo("Address successfully updated")).extract().response().asString();
	     
	     
	     // to get the api
	     
	     
	  String response=   given().log().all().queryParam("key", "qaclick123").header("Content-Type","application/json").queryParam("place_id", Place_ID)
	     .when().get("maps/api/place/get/json")
	     .then().assertThat().log().all().statusCode(200).extract().response().asString();
	     
	     
	     JsonPath js2= new JsonPath(response);
	     
	 String expectedaddress=    js2.get("address");
	 
	 System.out.println(expectedaddress);
	     
	     
	     
	     
	     
	     
	
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
