package STCPROJECT.seleniumframeworkstc;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StadaloneTest {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("");
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(15));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='Log in']")));
		
		
		Long starttome=System.currentTimeMillis();
		System.out.println(starttome);
		
		driver.findElement(By.xpath("//input[@id=\"userEmail\"]")).sendKeys("dileep499687@gmail.com");
		driver.findElement(By.xpath("//input[@id='userPassword']")).sendKeys("Summer@8");
		driver.findElement(By.xpath("//input[@id='login']")).click();
	    List<WebElement> products=	driver.findElements(By.cssSelector(".mb-3"));
	    
	    System.out.println(products.size());
	    
	    
	    Long endtime=System.currentTimeMillis();
	    System.out.println(endtime);
	    Long difference=endtime-starttome;
	    System.out.println(difference);
	    
	 WebElement prod=   products.stream().filter(product->product.findElement(By.cssSelector("b"))
			 .getText().equals("ZARA COAT 3")).findFirst().orElse(null);
	    
	    prod.findElement(By.cssSelector(".card-body button:last-of-type")).click();
	    
	// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='ng-tns-c4-14 toast-message ng-star-inserted']")));
	    
	   // wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div[@class='ng-tns-c4-14 toast-message ng-star-inserted']")));
	    
	//   wait.until(ExpectedConditions.invisibilityOf(driver.findElement(By.xpath("//div[@class='ng-tns-c4-14 toast-message ng-star-inserted']"))));
	    
	 //   driver.findElement(By.xpath("(//button[@class=\"btn btn-custom\"])[3]")).click();
	    
	  //  Thread.sleep(1000);
	    
	    try {
	        driver.findElement(By.xpath("(//button[@class=\"btn btn-custom\"])[3]")).click();
	     } catch (Exception e) {
	        JavascriptExecutor executor = (JavascriptExecutor) driver;
	        executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("(//button[@class=\"btn btn-custom\"])[3]")));
	     }
	    
	    
	 List<WebElement> cartproduct=   driver.findElements(By.xpath("//div[@class='cart']//h3"));
	 
	 
	boolean dert= cartproduct.stream().anyMatch(cart->cart.getText().equalsIgnoreCase("ZARA COAT 3"));
	
	Assert.assertTrue(dert);
	
	driver.findElement(By.xpath("//button[contains(text(),'Checkout')]")).click();
	
	
	Actions act= new Actions(driver);
	
	act.sendKeys(driver.findElement(By.xpath("//input[@placeholder='Select Country']")), "INDIA").build().perform();
	
	//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class='ta-item list-group-item ng-star-inserted']")));
	
	driver.findElement(By.xpath("(//button[@class='ta-item list-group-item ng-star-inserted'])[2]")).click();
	
	Thread.sleep(1000);
//	driver.findElement(By.xpath("//a[@class='btnn action__submit ng-star-inserted']")).click();
	
//	String confirmtext=driver.findElement(By.xpath("//h1[@class='hero-primary']")).getText();
	
	
//	boolean val=confirmtext.equalsIgnoreCase("THANKYOU FOR THE ORDER.");
	
//	Assert.assertTrue(val);
	
	
	
	
	 
	 
	 
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    
	    driver.quit();
	    
	    
	
	
		
		

	}

}
