package STCPROJECT.seleniumframeworkstc;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class StreamClass {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		WebDriverManager.chromedriver().setup();
		WebDriver driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com/?stype=lo&jlou=AfePqgPjBklqfJNUnHQoBhlYJXNgnApQjbHH1rZRzS30VACkDMtuPoGBTwYFyf_PvGsKJC2Fow6chUYHi8uZVYvtHGCLlk-H43sTgK04hAdQgA&smuh=18712&lh=Ac-KUgvFss0dfI1dwcg");

		WebDriverWait wait= new WebDriverWait(driver,Duration.ofSeconds(10));
		
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='_15lf']")));
		
		
        driver.findElement(By.xpath("//input[@id='email']")).sendKeys("dileepkumaar371@gmail.com");
        Thread.sleep(5000);
        driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("9338263328");
        driver.findElement(By.xpath("//*[@id='u_0_5_JO']")).click();
		
        
        
      String name=  driver.findElement(By.xpath("(//*[@style='height:36px;width:36px'])[1]")).getText();
      
      System.out.println(name);
      
      
		
		
	}

}
